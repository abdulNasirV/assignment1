﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class multipleOfNum
    {
        static void Main(string[] args)
        {
            int i;
            for (i = 1; i <= 25; i++)
            {
                Console.WriteLine("\n%d", i * i);
            }
        }
    }
}