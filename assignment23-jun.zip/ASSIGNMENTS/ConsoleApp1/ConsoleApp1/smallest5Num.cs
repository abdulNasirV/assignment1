﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class smallest5Num
    {

        public static void Main()
        {
            int n1, n2, n3, n4, n5;
            Console.WriteLine("Enter 5 no:");
            n1 = Convert.ToInt32(Console.ReadLine());
            n2 = Convert.ToInt32(Console.ReadLine());
            n3 = Convert.ToInt32(Console.ReadLine());
            n4 = Convert.ToInt32(Console.ReadLine());
            n5 = Convert.ToInt32(Console.ReadLine());
            if (n1 < n2)
                if (n1 < n3)
                    if(n1<n4)
                        if(n1<n5)
                {
                    Console.WriteLine("The Smallest Of Three numbers are:" + n1);
                }
                else
                {
                    Console.WriteLine("The Smallest Of Three numbers are:" + n5);
                }
            else
                {
                    Console.WriteLine("The Smallest Of Three numbers are:" + n4);
                }
            else
            {
                Console.WriteLine("The Smallest Of Three numbers are:" + n3);
            }
            else
                if (n4 < n5)
            {
                Console.WriteLine("The Smallest Of Three numbers are:" + n4);
            }
            else
            {
                Console.WriteLine("The Smallest Of Three numbers are:" + n5);
            }
        }
    }
}