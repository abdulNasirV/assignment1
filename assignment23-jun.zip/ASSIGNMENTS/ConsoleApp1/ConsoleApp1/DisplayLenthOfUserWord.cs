﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class DisplayLenthOfUserWord
    {
        public static void Main()
        {
            string str;
            int l = 0;

            Console.Write("\n Find the length of a string :\n");
            Console.Write("Input the string : ");
            str = Console.ReadLine();
            foreach (char chr in str)
            {
                l += 1;

            }
            Console.Write("Length of the string is : {0}\n", l);
        }
    }
}
