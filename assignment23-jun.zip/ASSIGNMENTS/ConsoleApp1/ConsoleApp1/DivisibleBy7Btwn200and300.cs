﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class DivisibleBy7Btwn200and300
    {
        public static void Main()
        {
            int i, sum = 0;
            Console.Write("Find the number and sum of all integer between 100 and 200, divisible by 7:\n");
            Console.Write("Numbers between 200 and 300, divisible by 7 : \n");
            for (i = 200; i < 300; i++)
            {
                if (i % 7 == 0)
                {
                    Console.Write("{0}  ", i);
                    sum += i;
                }
            }
            Console.Write("\n\nThe sum : {0} \n", sum);
        }
    }
}