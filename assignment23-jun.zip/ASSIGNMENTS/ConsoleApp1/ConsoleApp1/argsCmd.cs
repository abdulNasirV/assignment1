﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class argsCmd
    {
        public static void main(string[] args)

        {
            string name;

            Console.Write("Please enter your name: ");
            name = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("“Hi!  {0}.", name);
            Console.WriteLine("Welcome to the world of C#{0}", name);

        }
    }
}