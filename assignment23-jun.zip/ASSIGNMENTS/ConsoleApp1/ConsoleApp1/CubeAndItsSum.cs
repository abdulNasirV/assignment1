﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class CubeAndItsSum
    {
        static int sumOfSeries(int n)
        {
            int sum = 0;
            for (int x = 1; x <= n; x++)
                sum += x * x * x;
            return sum;
        }

       
        public static void Main()
        {
            int n;
            Console.Write("Enter a Number : ");
            n = int.Parse(Console.ReadLine());
            Console.Write(sumOfSeries(n));
        }
    }
}
