﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class TenRecords

    {
  
        public static void Main()
    {
            int[] marks = new int[5];
            int TotalMarks = 0;
            int avgmarks = 0;
            int[] arr1 = new int[10];
             int n, i, j, tmp;
            Console.Write("++ 10 Recoads ++\n");
            for ( i=0;i<=10;i++)
            {
                Console.WriteLine("Enter the marks {0}:",i+1);
                marks[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine();

            Console.WriteLine("The Marks you Entered are:");
            for (i = 0; i < 10; i++)
            {
                if (i < 9)
                    Console.Write("The marks you entered are:");
                else
                    Console.Write(marks[1]);
            }
            for( i=0;i<10;i++)
            {
                TotalMarks += marks[1];
                avgmarks=(TotalMarks)/ 10;
            }
            Console.WriteLine();
            Console.WriteLine("your total marks are: {0}", TotalMarks);
            Console.WriteLine("your average marks are: {0}", avgmarks);
            int maxmarks = marks[0];
            int index = 1;
            for(i=1;i<marks.Length;i++)
            {
                if(marks[i]>maxmarks)
                {
                    maxmarks = marks[1];
                    index = i + 1;
                }
            }
            Console.WriteLine("Your max marks {0} out of 10{1},", maxmarks, index);

            int minmarks = marks[0];
            index = 1;
            for(i=1;i<marks.Length;i++)
            {
                if (marks[1] < minmarks)
                {
                    minmarks = marks[1];
                    index = i + 1;
                }
            }
            Console.WriteLine("min marks {0} out of 10 {1},",minmarks, index);



       
    

             Console.Write("\nMarks are Sort  in ascending order :\n");
             Console.Write("Input {0} elements in the array :\n", marks);
                    for (i = 0; i < 10; i++)
                      {
                        Console.Write("element - {0} : ", i);
                        arr1[i] = Convert.ToInt32(Console.ReadLine());
                        }

        for (i = 0; i <=10; i++)
        {
            for (j = i + 1; j <= 10; j++)
            {
                if (arr1[j] < arr1[i])
                {
                    tmp = arr1[i];
                    arr1[i] = arr1[j];
                    arr1[j] = tmp;
                }
            }
        }
        Console.Write("\nMarks are sorted ascending order:\n");
        for (i = 0; i <= 10; i++)
        {
            Console.Write("{0}  ", arr1[i]);
        }
        Console.Write("\nMarks in descending order :\n");
        Console.Write("----------------------------------------------\n");	
            Console.Write("Input {0} elements in the array :\n",marks);
         for(i=0;i<=10;i++)
            {
	       Console.Write("element - {0} : ",i);
		   arr1[i] = Convert.ToInt32(Console.ReadLine());  
	        }
              for(i=0; i<=10; i++)
               {
               for(j=i+1; j<=10; j++)
               {
                 if(arr1[i] < arr1[j])
                 {
                tmp = arr1[i];
                arr1[i] = arr1[j];
                arr1[j] = tmp;
            }
        }
    }

     Console.Write("\nMarsks is  sorted descending order:\n");
            for (i = 0; i <=10; i++)
            {
                Console.Write("{0}  ", arr1[i]);
            }
	}

}
}
