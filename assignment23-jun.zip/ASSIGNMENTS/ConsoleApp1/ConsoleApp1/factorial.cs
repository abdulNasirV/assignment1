﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class factorial
    {
        public static void Main(string[] args)
        {
            int i, fact = 1, num;
            Console.Write("Enter any Number: ");
            num = int.Parse(Console.ReadLine());
            for (i = 1; i <= num; i++)
            {
                fact = fact * i;
            }
            Console.Write("Factorial of " + num + " is: " + fact);
        }
    }
}
