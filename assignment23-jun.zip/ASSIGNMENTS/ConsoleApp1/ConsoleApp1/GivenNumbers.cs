﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class GivenNumbers
    {

        public static void Main()
        {
            Console.WriteLine("Enter  the 2 no");
            int no1 = int.Parse(Console.ReadLine());
            int no2 = int.Parse(Console.ReadLine());
            int i = 0;
            do
            {
                Console.Write(i + "\t");
                i++;
            } while (i >= no1 && i <= no2);
            Console.ReadKey();


        }
    }
}